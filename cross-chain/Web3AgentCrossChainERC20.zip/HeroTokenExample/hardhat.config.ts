import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox-viem";
import "hardhat-deploy";
import "dotenv/config";

// const { PRIVATE_KEY = "" } = process.env;

const config: HardhatUserConfig = {
  solidity: {
    version: "0.8.20",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },
  namedAccounts: {
    deployer: {
      default: 0,
    },
  },
  networks: {
    "ethereum-sepolia": {
      url: "https://sepolia.infura.io/v3/7545b5b3e68246a9915a84ca5b9b5c68",
      accounts: [`${process.env.PRIVATE_KEY}`],
    },
    // for mainnet
    "blast-mainnet": {
      url: "coming end of February",
      accounts: [`${process.env.PRIVATE_KEY}`],
    },
    // for Sepolia testnetusdds
    "blast-sepolia": {
      url: "https://rpc.ankr.com/blast_testnet_sepolia/52b75d96b0312930727e185eff5208721ce56a5cc8c52f422a3f4385cc3949c8",
      accounts: [`${process.env.PRIVATE_KEY}`],
    },
    // for local dev environment
    "blast-local": {
      url: "http://localhost:8545",
      accounts: [`${process.env.PRIVATE_KEY}`],
      gasPrice: 1000000000,
    },
  },
};

export default config;