import { HardhatRuntimeEnvironment } from "hardhat/types";

const func: DeployFunction = async function (hre: HardhatRuntimeEnvironment) {
  const { deployments, getNamedAccounts } = hre;
  const { deploy } = deployments;
    
 
  const { deployer } = await getNamedAccounts();

  // `deployer` is a signer, which can be used to deploy contracts or send transactions
  console.log("Deployer address:", deployer.address);

  console.log("Deployer done");
 
  await deploy("GeroXL1Token", {
    from: deployer,
    contract: "GeroXL1Token",
    log: true,
  });
};
export default func;
func.tags = ["GeroXL1Token"];