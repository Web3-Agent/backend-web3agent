import { HardhatRuntimeEnvironment } from "hardhat/types";
import { DeployFunction } from "hardhat-deploy/types";
import config from "../config";

const func: DeployFunction = async function (hre: HardhatRuntimeEnvironment) {
  const { deployments, getNamedAccounts } = hre;
  const { deploy } = deployments;

  const L1Token = "0x09b352061Bc07792cC2243bDfA614C8fDce8eABA";

  if (!L1Token) {
    throw new Error("L1Token is not set in L2 deploy script.");
  }
  const L2BridgeAddress = config.blastSepoliaL2Bridge;

  const { deployer } = await getNamedAccounts();
  await deploy("GeroXL2Token", {
    from: deployer,
    contract: "GeroXL2Token",
    args: [L2BridgeAddress, L1Token],
    log: true,
  });
};

export default func;
func.tags = ["GeroXL2Token"];
